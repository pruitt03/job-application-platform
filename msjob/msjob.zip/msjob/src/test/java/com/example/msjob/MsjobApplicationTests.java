package com.example.msjob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsjobApplicationTests {

	@Test
	void contextLoads() {
	}

}
