package com.example.msjob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class MsjobApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsjobApplication.class, args);
	}

}
